<?php
include('inc/connection.php');
session_start();
 // check if user login or not 
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location:index.html#log'); 
    exit();
}
  // tols part 
if (isset($_POST['submit'])){ 
    $url = stripcslashes($_POST['Url']);
    $url = htmlentities(mysqli_real_escape_string($con,$_POST['Url']));

    // Execute Bash script with URL as argument
    $output = shell_exec("bash execute_ffuf.sh " . escapeshellarg($url));

    // Display output in HTML format
    echo "<pre>$output</pre>";
}
?>
